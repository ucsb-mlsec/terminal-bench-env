#ifndef LIB2_H
#define LIB2_H

int lib2_function();

#endif // LIB2_H