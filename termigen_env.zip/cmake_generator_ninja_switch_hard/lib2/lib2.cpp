#include "lib2.h"

int lib2_function() {
    return 100;
}