#ifndef LIB1_H
#define LIB1_H

int lib1_function();

#endif // LIB1_H