#include "lib1.h"

int lib1_function()
{
    return 42;
}