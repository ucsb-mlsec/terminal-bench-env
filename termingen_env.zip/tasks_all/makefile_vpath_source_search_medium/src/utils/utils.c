#include <stdio.h>

void print_message(void) {
    printf("Utility function called\n");
}

void process_string(char* str) {
    printf("Processing string: %s\n", str);
}