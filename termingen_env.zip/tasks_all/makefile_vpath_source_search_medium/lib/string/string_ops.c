#include <stdio.h>
#include <string.h>

int multiply(int a, int b) {
    return a * b;
}

int string_length(char* str) {
    return strlen(str);
}