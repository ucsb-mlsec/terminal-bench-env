#include "lib.h"

const char* get_message() {
    return "Hello from library!";
}