#ifndef LIB_H
#define LIB_H

const char* get_message();

#endif