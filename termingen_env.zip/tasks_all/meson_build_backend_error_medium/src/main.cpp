#include <iostream>
#include "lib.h"

int main() {
    std::cout << get_message() << std::endl;
    return 0;
}