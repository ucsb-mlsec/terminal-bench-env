#include "math_functions.h"

int add(int a, int b) {
    return a + b;
}

int multiply(int a, int b) {
    // Deliberate bug: using addition instead of multiplication
    return a + b;
}