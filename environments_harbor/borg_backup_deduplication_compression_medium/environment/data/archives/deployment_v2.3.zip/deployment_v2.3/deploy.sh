#!/bin/bash
set -e
echo 'Starting deployment v2.3'

# Pull latest images
docker pull myapp:v2.3

# Stop old containers
docker-compose down

# Start new containers
docker-compose up -d

echo 'Deployment complete'
