# Deployment Package v2.3

This package contains all files needed for deployment.

## Contents
- deploy.sh: Main deployment script
- docker-compose.yml: Container orchestration
- config/: Configuration files
- scripts/: Database initialization scripts

## Usage
```bash
bash deploy.sh
```
