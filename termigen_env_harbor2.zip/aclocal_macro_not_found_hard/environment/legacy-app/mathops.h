#ifndef MATHOPS_H
#define MATHOPS_H

/* Mathematical operations for legacy-app */

double add(double a, double b);
double subtract(double a, double b);
double multiply(double a, double b);
double divide(double a, double b);

#endif /* MATHOPS_H */